package com.example.dev_spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class DevSpringApplicationTests {

	@Test
	void contextLoads() {
	}

}
